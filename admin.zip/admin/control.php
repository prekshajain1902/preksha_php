<?php
include_once('model.php');

class Control extends model
{
	
	function __construct()
	{
		session_start();
        model::__construct();

		$PATH = $_SERVER['PATH_INFO'];  

		switch ($PATH) {
			
			case'/login':
			if(isset($_REQUEST['submit']))
			{
				$username=$_REQUEST['username'];
				$pass=md5($_REQUEST['pass']); 
				
				$arr=array("username"=>$username,"pass"=>$pass);
				
			 $res=$this->select_where('admin',$arr); // func call  and cond check 
				$chk=$res->num_rows; // check res by rows that cond true or not
			
				if($chk==1) // 1 means true / and 0 means false
				{
					$fetch=$res->fetch_object(); // data fetch after function call
					// session create 
					$_SESSION['admin_id']=$fetch->admin_id;
					$_SESSION['username']=$fetch->username;
					$_SESSION['name']=$fetch->name;
					
					
					echo "
					<script>
					alert('Login Success');
					window.location='Dashboard';
					</script>
					";
				}
				else
				{
					echo "
					<script>
					alert('Login Failed due to wrong creadential !');
					window.location='login';
					</script>
					";
				}
			}
			include_once('Login.php');
			break;
			
			case '/adminlogout':
			unset($_SESSION['admin_id']);
			unset($_SESSION['username']);
			unset($_SESSION['admin']);
			echo "
					<script>
					alert('Logout Success');
					window.location='login';
					</script>
					";
			break;
			
			
			case '/Dashboard':
			include_once('Dashboard.php');
			break;
			
			case '/add_emp':
				include_once('add_emp.php');
				break;

			case '/manage_emp':
			    $emp_arr=$this->select('employee');
				include_once('manage_emp.php');
				break;

			case '/add_cat':
				include_once('add_cat.php');
				break;

			case '/manage_cat':
			    $cat_arr=$this->select('categroy');
				include_once('manage_cat.php');
				break;

		    case '/add_loc':
				include_once('add_loc.php');
				break;

		    case '/manage_loc':
		     $loc_arr=$this->select('location');
				include_once('manage_loc.php');
				break;

		    case '/manage_user':
		    if(isset($_REQUEST['search']))
			{
				$search=$_REQUEST['search'];
				$user_arr=$this->select_search('user','name',$search);
			}
			else
			{
				  $user_arr=$this->select('user');
			}
				include_once('manage_user.php');
				break;

		    case '/manage_con':
		     $con_arr=$this->select('contact');
				include_once('manage_con.php');
				break;

			case '/manage_car':
			 $car_arr=$this->select('car_adv');
				include_once('manage_car.php');
				break;


			case '/delete':
			if(isset($_REQUEST['del_contact_id']))
			{
				$contact_id=$_REQUEST['del_contact_id'];
				$where=array("contact_id"=>$contact_id);
				
				$res=$this->delete_where('contact',$where);
				if($res)
				{
					echo "
					<script>
					alert('Delete Success');
					window.location='manage_con';
					</script>
					";
				}
			}
			if(isset($_REQUEST['del_user_id']))
			{
				$user_id=$_REQUEST['del_user_id'];
				$where=array("user_id"=>$user_id);
				
				$res=$this->delete_where('user',$where);
				if($res)
				{
					echo "
					<script>
					alert('Delete Success');
					window.location='manage_user';
					</script>
					";
				}
			}
			break;

		     case '/status':
			if(isset($_REQUEST['status_user_id']))
			{
				$user_id=$_REQUEST['status_user_id'];
				$where=array("user_id"=>$user_id);
				
				$res=$this->select_where('user',$where);
				$fetch=$res->fetch_object();
				
				if($fetch->status=="block")
				{
					$arr=array("status"=>"unblock");
					$res=$this->update('user',$arr,$where);
					if($res)
					{
						echo  "
						<script>
						alert('Customer Unblock Success');
						window.location='manage_user';
						</script>
						";
					}
				}
				else
				{
					$arr=array("status"=>"block");
					$res=$this->update('user',$arr,$where);
					if($res)
					{
						echo "
						<script>
						alert('Customer Block Success');
						window.location='manage_user';
						</script>
						";
					}
				}
			}
			
			break;     
		}

	}
}

$obj = new Control();

?>